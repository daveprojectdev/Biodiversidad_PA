"""
importar_aves.py — Importar dataset Aves a MySQL
Sistema de Biodiversidad de Panamá
Autores: David Ameth Martínez Sánchez | Emanuel Quintero
Fuente: GBIF CC BY-NC 4.0 | Aves | Panamá | 2024-2026
"""

import pandas as pd
import mysql.connector
from mysql.connector import Error
import os, sys

# ──────────────────────────────────────────────────────────────
# CONFIGURACIÓN — ajustar según el equipo
# ──────────────────────────────────────────────────────────────
DB_CONFIG = {
    'host':     'localhost',
    'port':     3306,
    'user':     'root',
    'password': 'tu_password',   # <-- cambiar
    'charset':  'utf8mb4',
}
DB_NAME  = 'biodiversidad_aves'
CSV_DIR  = os.path.dirname(os.path.abspath(__file__)) + '/aves_refinado'

# ──────────────────────────────────────────────────────────────
# UTILIDADES
# ──────────────────────────────────────────────────────────────
def conectar(db=None):
    cfg = DB_CONFIG.copy()
    if db:
        cfg['database'] = db
    return mysql.connector.connect(**cfg)


def ejecutar(cursor, sql, valores=None):
    if valores:
        cursor.execute(sql, valores)
    else:
        cursor.execute(sql)


def insertar_lote(conn, cursor, sql, filas, tam_lote=1000):
    total = 0
    for i in range(0, len(filas), tam_lote):
        lote = filas[i:i + tam_lote]
        cursor.executemany(sql, lote)
        conn.commit()
        total += len(lote)
        print(f"    {total:>7,} / {len(filas):,}", end='\r')
    print(f"    {total:,} registros insertados      ")


# ──────────────────────────────────────────────────────────────
# DDL — crear base de datos y tablas
# ──────────────────────────────────────────────────────────────
DDL = """
CREATE DATABASE IF NOT EXISTS biodiversidad_aves
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE biodiversidad_aves;

CREATE TABLE IF NOT EXISTS orden (
    orden_id  INT         NOT NULL AUTO_INCREMENT,
    nombre    VARCHAR(50) NOT NULL,
    CONSTRAINT pk_orden        PRIMARY KEY (orden_id),
    CONSTRAINT uq_orden_nombre UNIQUE (nombre)
) ENGINE=InnoDB COMMENT='Ordenes de Aves en Panama';

CREATE TABLE IF NOT EXISTS familia (
    familia_id INT         NOT NULL AUTO_INCREMENT,
    nombre     VARCHAR(100) NOT NULL,
    orden_id   INT         NOT NULL,
    CONSTRAINT pk_familia        PRIMARY KEY (familia_id),
    CONSTRAINT uq_familia_nombre UNIQUE (nombre),
    CONSTRAINT fk_familia_orden  FOREIGN KEY (orden_id)
        REFERENCES orden(orden_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB COMMENT='Familias de Aves en Panama';

CREATE TABLE IF NOT EXISTS especie (
    especie_id         INT          NOT NULL AUTO_INCREMENT,
    nombre_cientifico  VARCHAR(150) NOT NULL,
    genero             VARCHAR(50)  NOT NULL,
    familia_id         INT          NOT NULL,
    CONSTRAINT pk_especie                    PRIMARY KEY (especie_id),
    CONSTRAINT uq_especie_nombre_cientifico  UNIQUE (nombre_cientifico),
    CONSTRAINT fk_especie_familia            FOREIGN KEY (familia_id)
        REFERENCES familia(familia_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB COMMENT='Especies de Aves en Panama';

CREATE TABLE IF NOT EXISTS provincia (
    provincia_id INT         NOT NULL AUTO_INCREMENT,
    nombre       VARCHAR(100) NOT NULL,
    CONSTRAINT pk_provincia        PRIMARY KEY (provincia_id),
    CONSTRAINT uq_provincia_nombre UNIQUE (nombre)
) ENGINE=InnoDB COMMENT='Provincias y comarcas de Panama';

CREATE TABLE IF NOT EXISTS observador (
    observador_id INT          NOT NULL AUTO_INCREMENT,
    nombre        VARCHAR(150) NOT NULL,
    CONSTRAINT pk_observador PRIMARY KEY (observador_id)
) ENGINE=InnoDB COMMENT='Observadores ciudadanos de iNaturalist';

CREATE INDEX IF NOT EXISTS idx_obs_nombre ON observador(nombre);

CREATE TABLE IF NOT EXISTS fuente (
    fuente_id   INT          NOT NULL AUTO_INCREMENT,
    nombre      VARCHAR(100) NOT NULL,
    url         VARCHAR(255) NULL,
    licencia    VARCHAR(30)  NULL,
    descripcion VARCHAR(255) NULL,
    CONSTRAINT pk_fuente        PRIMARY KEY (fuente_id),
    CONSTRAINT uq_fuente_nombre UNIQUE (nombre)
) ENGINE=InnoDB COMMENT='Fuentes de datos: iNaturalist, GBIF';

CREATE TABLE IF NOT EXISTS avistamiento (
    avistamiento_id INT            NOT NULL AUTO_INCREMENT,
    gbif_id         BIGINT         NOT NULL,
    especie_id      INT            NOT NULL,
    provincia_id    INT            NOT NULL,
    observador_id   INT            NOT NULL,
    fuente_id       INT            NOT NULL,
    latitud         DECIMAL(9,6)   NOT NULL,
    longitud        DECIMAL(9,6)   NOT NULL,
    fecha           DATE           NOT NULL,
    mes             TINYINT        NOT NULL,
    anio            SMALLINT       NOT NULL,
    licencia        VARCHAR(20)    NOT NULL,
    occurrence_url  VARCHAR(100)   NULL,
    media_type      VARCHAR(20)    NULL,
    CONSTRAINT pk_avistamiento        PRIMARY KEY (avistamiento_id),
    CONSTRAINT uq_avist_gbif_id       UNIQUE (gbif_id),
    CONSTRAINT fk_avist_especie       FOREIGN KEY (especie_id)
        REFERENCES especie(especie_id)     ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_avist_provincia     FOREIGN KEY (provincia_id)
        REFERENCES provincia(provincia_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_avist_observador    FOREIGN KEY (observador_id)
        REFERENCES observador(observador_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_avist_fuente        FOREIGN KEY (fuente_id)
        REFERENCES fuente(fuente_id)       ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_mes        CHECK (mes BETWEEN 1 AND 12),
    CONSTRAINT chk_anio       CHECK (anio BETWEEN 2000 AND 2100),
    CONSTRAINT chk_latitud    CHECK (latitud  BETWEEN -90  AND  90),
    CONSTRAINT chk_longitud   CHECK (longitud BETWEEN -180 AND 180),
    CONSTRAINT chk_licencia   CHECK (licencia IN ('CC_BY_NC_4_0','CC_BY_4_0','CC0_1_0')),
    CONSTRAINT chk_media_type CHECK (media_type IN ('StillImage','Sound','StillImage;Sound') OR media_type IS NULL)
) ENGINE=InnoDB COMMENT='Avistamientos de Aves en Panama (GBIF 2024-2026)';

CREATE INDEX IF NOT EXISTS idx_avist_especie   ON avistamiento(especie_id);
CREATE INDEX IF NOT EXISTS idx_avist_provincia ON avistamiento(provincia_id);
CREATE INDEX IF NOT EXISTS idx_avist_anio_mes  ON avistamiento(anio, mes);
CREATE INDEX IF NOT EXISTS idx_avist_media     ON avistamiento(media_type);
"""


# ──────────────────────────────────────────────────────────────
# IMPORTACIÓN
# ──────────────────────────────────────────────────────────────
def importar():
    print("=" * 60)
    print("Importando dataset Aves → biodiversidad_aves")
    print("=" * 60)

    # 1. Crear BD y tablas
    conn = conectar()
    cursor = conn.cursor()
    for stmt in DDL.strip().split(';'):
        stmt = stmt.strip()
        if stmt:
            cursor.execute(stmt)
    conn.commit()
    cursor.close()
    conn.close()
    print("✅ Base de datos y tablas creadas")

    conn = conectar(DB_NAME)
    cursor = conn.cursor()

    # 2. Orden
    print("\n[1/6] Insertando ORDEN...")
    df = pd.read_csv(f'{CSV_DIR}/orden.csv')
    sql = "INSERT IGNORE INTO orden (orden_id, nombre) VALUES (%s, %s)"
    insertar_lote(conn, cursor, sql,
                  list(df.itertuples(index=False, name=None)))

    # 3. Familia
    print("[2/6] Insertando FAMILIA...")
    df = pd.read_csv(f'{CSV_DIR}/familia.csv')
    sql = "INSERT IGNORE INTO familia (familia_id, nombre, orden_id) VALUES (%s, %s, %s)"
    insertar_lote(conn, cursor, sql,
                  list(df.itertuples(index=False, name=None)))

    # 4. Especie
    print("[3/6] Insertando ESPECIE...")
    df = pd.read_csv(f'{CSV_DIR}/especie.csv')
    sql = "INSERT IGNORE INTO especie (especie_id, nombre_cientifico, genero, familia_id) VALUES (%s, %s, %s, %s)"
    insertar_lote(conn, cursor, sql,
                  list(df.itertuples(index=False, name=None)))

    # 5. Provincia
    print("[4/6] Insertando PROVINCIA...")
    df = pd.read_csv(f'{CSV_DIR}/provincia.csv')
    sql = "INSERT IGNORE INTO provincia (provincia_id, nombre) VALUES (%s, %s)"
    insertar_lote(conn, cursor, sql,
                  list(df.itertuples(index=False, name=None)))

    # 6. Observador
    print("[5/6] Insertando OBSERVADOR...")
    df = pd.read_csv(f'{CSV_DIR}/observador.csv')
    sql = "INSERT IGNORE INTO observador (observador_id, nombre) VALUES (%s, %s)"
    insertar_lote(conn, cursor, sql,
                  list(df.itertuples(index=False, name=None)))

    # 7. Fuente
    cursor.execute("""
        INSERT IGNORE INTO fuente (fuente_id, nombre, url, licencia, descripcion) VALUES
        (1, 'iNaturalist', 'https://www.inaturalist.org', 'CC_BY_NC_4_0',
         'Red social de ciencia ciudadana para registro de biodiversidad')
    """)
    conn.commit()

    # 8. Avistamiento
    print("[6/6] Insertando AVISTAMIENTO (54,606 filas)...")
    df = pd.read_csv(f'{CSV_DIR}/avistamiento.csv')
    # Convertir NaN → None para MySQL
    df = df.where(pd.notnull(df), None)
    df['gbif_id']      = df['gbif_id'].astype('Int64')
    df['especie_id']   = df['especie_id'].astype(int)
    df['provincia_id'] = df['provincia_id'].astype(int)
    df['observador_id']= df['observador_id'].astype(int)

    sql = """INSERT IGNORE INTO avistamiento
             (avistamiento_id, gbif_id, especie_id, provincia_id, observador_id, fuente_id,
              latitud, longitud, fecha, mes, anio, licencia, occurrence_url, media_type)
             VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
    cols = ['avistamiento_id','gbif_id','especie_id','provincia_id','observador_id','fuente_id',
            'latitud','longitud','fecha','mes','anio','licencia','occurrence_url','media_type']
    filas = [tuple(r) for r in df[cols].itertuples(index=False, name=None)]
    insertar_lote(conn, cursor, sql, filas, tam_lote=500)

    cursor.close()
    conn.close()

    print("\n✅ Importación completa")
    print("\n-- Verificación rápida --")
    print("""
SELECT 'orden'        AS tabla, COUNT(*) AS n FROM orden
UNION ALL SELECT 'familia',     COUNT(*) FROM familia
UNION ALL SELECT 'especie',     COUNT(*) FROM especie
UNION ALL SELECT 'provincia',   COUNT(*) FROM provincia
UNION ALL SELECT 'observador',  COUNT(*) FROM observador
UNION ALL SELECT 'fuente',      COUNT(*) FROM fuente
UNION ALL SELECT 'avistamiento',COUNT(*) FROM avistamiento;
""")


if __name__ == '__main__':
    importar()
